<?php

include_once ENTROPIA_CORE_CPT_PATH . '/team/team-register.php';
include_once ENTROPIA_CORE_CPT_PATH . '/team/helper-functions.php';