<?php

get_header();

entropia_edge_get_title();

do_action('entropia_edge_action_before_main_content');

entropia_core_get_single_team();

get_footer();