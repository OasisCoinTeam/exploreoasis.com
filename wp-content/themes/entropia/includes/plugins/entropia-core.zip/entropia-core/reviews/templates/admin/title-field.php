<p>
    <label for="title"><?php esc_html_e( 'Comment Title', 'entropia-core' ); ?></label>
    <input type="text" name="edgtf_comment_title" value="<?php echo esc_attr( $title ); ?>" class="widefat" />
</p>