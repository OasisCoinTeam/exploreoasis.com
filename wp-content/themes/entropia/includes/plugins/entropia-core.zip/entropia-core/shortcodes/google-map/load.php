<?php

include_once ENTROPIA_CORE_SHORTCODES_PATH . '/google-map/functions.php';
include_once ENTROPIA_CORE_SHORTCODES_PATH . '/google-map/google-map.php';